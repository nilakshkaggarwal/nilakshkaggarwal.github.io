# Date Time Format

Let's say date is 

1. Thu 30 August 2018 8:42:54 (UTC +05:30)
2. Sat 6 October 2018 23:01:08 (UTC +05:30)

It's format is `ddd dd MMMM yyyy H:mm:ss (UTC zzz)`

|Format|Denotion|Thu 30 August 2018 8:42:54 (UTC +05:30)|Sat 6 October 2018 23:01:08 (UTC +05:30)|
|-|-|-|-|
|d|single digit Date|30| 6|
|dd| Double digit Date|30| 06|
|ddd| day of the week|Thu| Sat|
|dddd|day of the week (full) |Thurday| Saturday|
|D|non recognizable|-|
|h|single digit hour (12 hr format)|8| 11|
|hh|double digit hour (12 hr format)|08| 11|
|H|single digit hour (24 hr format)|8| 23|
|HH|double digit hour (24 hr format)|08| 23|
|M|single digit Month|8| 10|
|MM|Double digit month|08| 10|
|MMM|Three alphabet month| Aug| Oct|
|MMMM|Full Month Name| August| October|
|m|single digit minute|42| 1|
|mm|double digit minute|42| 01|
|mmm|read as mm,m|4242| 011|
|tt|AM/PM|AM|PM|
|yy|2 digit year| 18| 18|
|yyy|2 digit year followed by y| 18y| 18y|
|yyyy| 4 digit year| 2018| 2018|
|f|one-tenths of second, more accuracy increase the no. of f (fff miliseconds, ffffff microseconds)|0| 0|
|z|single digit time Zone, shows integer value for fractional time zones| +5| +5|
|zz|double digit time Zone, shows integer value for fractional time zones| +05| +05|
|zzz| Complete time zone| +05:30| +05:30|

Anything else mentioned in datetime display format will be displayed as it is

for e.g. take these 2 dates 

1. Thu 30 August 2018 8:42:54 (UTC +05:30)
2. Sat 6 October 2018 23:01:08 (UTC +05:30)

|Display Format|Example 1|Example 2|
|-|-|-|
|MM-dd-yyyy| 08-30-2018| 10-06-2018|
|ddd, dd-MMM-yyyy| Thu, 30-Aug-2018|Sat, 06-Oct-2018|
|MMM/dd/yyyy|Aug/30/2018|Oct/06/2018|
|MM/dd/yyyy|08/30/2018|10/06/2018|
|MM.dd.yyyy|08.30.2018|10.06.2018|
|yyyy/MM/dd HH:mm:ss|2018/08/30 08:42:54|2018/10/06 23:01:08|
|yyyy/MM/dd HH:mm|2018/08/30 08:42|2018/10/06 23:01|
|yyyy/MM/dd|2018/08/30|2018/10/06|
|dd/MMM/yyyy|30/Aug/2018|06/Oct/2018|
|dd/MM/yyyy|30/08/2018|06/10/2018|
|dd-MM-yyyyTHH:mm:ss|30-08-2018T08:42:54|06-10-2018T23:01:08|
|dd-MM-yyyy|30-08-2018|06-10-2018|
|dd-MMM-yyyyTHH:mm:ss|30-Aug-2018T08:42:54|06-Oct-2018T23:01:08|
|dd-MMM-yyyy HH:mm:ss|30-Aug-2018 08:42:54|06-Oct-2018 23:01:08|
|dd-MMM-yyyy HH:mm|30-Aug-2018 08:42|06-Oct-2018 23:01|
|dd-MMM-yyyy|30-Aug-2018|06-Oct-2018|
|dd-MMM-yy|30-Aug-18|06-Oct-18|
|ddd MMM dd yyyy HH:mm:ss|Thu Aug 30 2018 08:42:54|Sat Oct 06 2018 23:01:08|
|yyyy-MM-ddTHH:mm:ss.fffffffzzz|2018-08-30T08:42:54.000000+05:30|2018-10-06T23:01:08.000000+05:30|
|yyyy-MM-ddTHH:mm:ss.fffzzz|2018-08-30T08:42:54.000+05:30|2018-10-06T23:01:08.000+05:30|
|yyyy-MM-ddTHH:mm:sszzz|2018-08-30T08:42:54+05:30|2018-10-06T23:01:08+05:30|
|yyyy-MM-ddTHH:mm:ss.fffffff|2018-08-30T08:42:54.000000|2018-10-06T23:01:08.000000|
|yyyy-MM-ddTHH:mm:ss.fff|2018-08-30T08:42:54.000|2018-10-06T23:01:08.000|
|yyyy-MM-ddTHH:mmzzz|2018-08-30T08:42+05:30|2018-10-06T23:01+05:30|
|yyyy-MM-ddTHH:mm:ss|2018-08-30T08:42:54|2018-10-06T23:01:08|
|yyyy-MM-ddTHH:mm|2018-08-30T08:42|2018-10-06T23:01|
|yyyy-MM-dd HH:mm:ss|2018-08-30 08:42:54|2018-10-06 23:01:08|
|yyyy-MM-dd HH:mm|2018-08-30 08:42|2018-10-06 23:01|
|yyyy-MM-dd|2018-08-30|2018-10-06|
|MMM-yy|Aug-18|Oct-18|
|HH:mm:ss|08:42:54|23:01:08|
|HH:mm|08:42|23:01|
|h:mm:ss tt| 8:42:54 AM|11:01:08 PM|
|yyeahH!|18ea88!| 18ea1123!|
|M..mmattyy|8..42aAM18| 10..01aPM18|
|jumps over little dog.|ju42p54 over liAMle 30og.|ju1p8 over liPMle 6og.|

Explanation: yy,h,H in third last case and M,mm,tt,yy in second last case has been recognised seperately, similarly for last case and those has been assigned corresponding values

Default Format: `yyyy-MM-ddThh:mm:ss.ffffffzzz`
