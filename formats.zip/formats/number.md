
# Number Formats

|Format Symbol|Description|
|-|-|
|**;**|Seperate positive no. format from negative no. format|
|**,**| putting `,` anywhere in the format string displays numbers with commas like 12345 → 12,345|
|**$**|Currency Marker, shows local format with language selection in tenant (e.g. $ in en-US, ₹ in en-IN)|
|**.**|decimal point seperator. |
|**a**|ending the number format with `a` displays the no. as 1.1m 78k|
|**o**|ending format string with `o` display no. like 1st, 34th|
|**%**|ending format string `%` converts the ratio to percentage (multiplies by 100 too)|
|**.000…0**|Maximum no. of digits after decimal is determined by no. of zeroes. numbers are forced to be of this length extra zeroes are added (2.1 → 2.100…0)|
|**.[000…0]**|Maximum no. of digits after decimal is determined by no. of zeroes, extra zeroes are not been added (2.1 → 2.1)|

Remember: 0 has been used but any other character (like #) would also give same result except `a` `o` `( )`

There should **always** be a character before decimal point. Generally #, 0 are used

1. Example 1 = 1234567.1256
2. Example 2 = -9875.23

|Format String|Example 1|Example 2|
|-|-|-|
||1234567|-9875|
|**#.00**|1234567.13|-9875.23|
|**.00**|.13|-.23|
|**#.0000**|1234567.1256|-9857.2300|
|**#.[0000]**|1234567.1256|-9857.23|
|**#.00,**|1,234,567.126|-9,875.230|
|**,.00**|1,234,567.13|-9,875.23|
|**$ ,.00**|$ 1,234,567.13|-$ 9,875.23|
|**#.00 a**|1.23 m|-9.86 k|
|**.00 a**|.23 m|-.86 k|
|**,.00;**|1,234,567.13|-9875|
|**;,.00**|1234567|-9,875.00|
|**,.00;(,.00)**|1,234,567.13|(9,875.23)|
|**#.00 a;( ,.00)**|1.23 m|(9,875.23)|
|**%**|123456713%|-987523%|